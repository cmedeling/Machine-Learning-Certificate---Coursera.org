function [X_norm, mu, sigma] = featureNormalize(X)
%FEATURENORMALIZE Normalizes the features in X 
%   FEATURENORMALIZE(X) returns a normalized version of X where
%   the mean value of each feature is 0 and the standard deviation
%   is 1. This is often a good preprocessing step to do when
%   working with learning algorithms.

% You need to set these values correctly
X_norm = X;
mu = zeros(1, size(X, 2));
sigma = zeros(1, size(X, 2));

% ====================== YOUR CODE HERE ======================
% Instructions: First, for each feature dimension, compute the mean
%               of the feature and subtract it from the dataset,
%               storing the mean value in mu. Next, compute the 
%               standard deviation of each feature and divide
%               each feature by it's standard deviation, storing
%               the standard deviation in sigma. 
%
%               Note that X is a matrix where each column is a 
%               feature and each row is an example. You need 
%               to perform the normalization separately for 
%               each feature. 
%
% Hint: You might find the 'mean' and 'std' functions useful.
%       
X = [ones(length(X),1), X];
meanX = mean(X);
meanX1 = meanX(1);
meanX2 = meanX(2);
meanX3 = meanX(3);
for i = 1:3
   mu(i) = X(i)-meanX(i); 
end

% mu(1) = X(1)-meanX1;
% mu(2) = X(2)-meanX2;
% mu(3) = X(3)-meanX3;

sigmaX = sigma(X);
sigmaX1 = sigmaX(1);
sigmaX2 = sigmaX(2);
sigmaX3 = sigmaX(3);






% ============================================================

end
