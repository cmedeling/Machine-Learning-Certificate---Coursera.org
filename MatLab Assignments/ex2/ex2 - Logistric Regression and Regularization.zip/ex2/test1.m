X42 = randi(10, 4,2)
X43 = [ones(4,1) X42]
Y24 = randi(10, 2, 4)
test = X42.*Y24'